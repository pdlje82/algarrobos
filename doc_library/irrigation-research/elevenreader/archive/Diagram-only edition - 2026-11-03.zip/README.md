# Illustrated irrigation listening edition

Prepared 3 November 2026 as an adaptation of LEARN-016. This is the same research topic in a narration-friendly form, retaining the technical comparisons, uncertainty, example budgets and proposed experiment. Sources and bibliographic details remain in companions rather than interrupting the spoken reading.

- [EPUB for ElevenReader](Irrigation%20for%20a%20Native%20Restoration%20Park.epub): twelve chapters, 5,632 words, approximately 35–43 minutes at 130–160 words per minute. All twelve original high-resolution diagrams are embedded inside the EPUB, at the corresponding passages. They do not need an external image connection.
- [Browser read-along edition](Irrigation%20-%20Read%20Along.html): the same narration and all twelve diagrams in one self-contained file. Select a diagram to enlarge it, then scroll within the enlarged image if needed. Escape or Close dismisses the image.
- [Illustrated Markdown manuscript](Irrigation%20-%20Illustrated%20Listening%20Edition.md): editable prose with links to the original package's figures.
- [Plain narration](Irrigation%20-%20Narration.txt): the spoken text without image placeholders or citations.
- [Sources and production notes](Sources%20and%20production%20notes.md): chapter mapping, direct document downloads, format decisions and checks.
- [Package checks](Publication%20checks.json) and [browser checks](Browser%20checks.json): retained verification results.

Import the EPUB using ElevenReader's file-upload option. EPUB support is documented by the [ElevenReader Team, updated 30 October 2026](https://elevenreader.io/blog/epub-text-to-speech). Direct import, narration, image retention and word highlighting inside ElevenReader have not been tested for this file. The browser copy provides a separate way to follow the complete illustrated text; it is not synchronised with ElevenReader playback.

No audio track was generated. Voice choice and playback speed are selected in ElevenReader. Technical diagram labels remain inside images, while nearby prose explains their important content without requiring the reader to interpret the drawing.

The original research report and figure files are unchanged. This is a companion edition under the existing LEARN-016 catalogue entry, not a new source document or a new field study. No project setting, species watering rule, funding score or field installation is adopted by producing the edition.

To rebuild, run `python doc_library/irrigation-research/elevenreader/build_epub.py` from the repository root. It validates the chapter sequence, complete text, manifest, resource references, navigation and unchanged original image bytes before replacing the EPUB. Optional browser checks use `node doc_library/irrigation-research/elevenreader/check_read_along.mjs`, with Node 22 or newer and the configured Chrome executable. This browser check creates temporary screenshots and does not use a personal browser profile.
