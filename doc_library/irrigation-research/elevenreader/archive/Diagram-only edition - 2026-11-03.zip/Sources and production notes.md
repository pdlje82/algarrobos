# Sources and production notes for the irrigation listening edition

Prepared 3 November 2026. Language: English. This edition adapts [the original LEARN-016 research report](../../LEARN-016%20-%20Almeria%20Restoration%20-%20Irrigation%20Technology%20and%20Demonstrator%20Research%20-%202026-11-03.md), with its [full source register](../SOURCES.md), into prose suited to listening. It is an editorial adaptation rather than new irrigation research. All qualifications about site validation, costs, programme eligibility and source access remain applicable.

## Chapter coverage

| Listening chapter | Original report coverage | Embedded illustrations |
|---|---|---|
| One. What irrigation should achieve | Opening recommendation; section 1 control choices | 1, control architectures |
| Two. Common practice and the Almería experience | Section 1, including local services and unresolved establishment doses | None |
| Three. The technology available today | Section 2 market/open-hardware comparison | None |
| Four. Tanks, planting islands and hydraulic pressure | Section 3 | 2, landscape; 3, hydraulics; 4, pressure |
| Five. Sensors and locally assembled electronics | Section 4 | 5, node; 6, placement |
| Six. Individual control without batteries | Section 5 | 7, passive mechanism |
| Seven. Wireless supervision with local autonomy | Section 6 communications, intelligence and dashboard | 8, communications |
| Eight. Proving delivery and handling failures | Section 6 measurement and fault policy | 9, control states |
| Nine. Water storage and solar energy | Section 7 | 10, water and energy |
| Ten. Cost, local work and repairability | Section 8 | 11, repair modules |
| Eleven. A demonstrator that can answer useful questions | Section 10 | 12, comparison trial |
| Twelve. Novelty, funding and the decisions ahead | Sections 9 and 11 | None |

The original bibliography and download section are intentionally outside the narrated spine. Table rows are expressed as connected prose; symbols, units, prices and calculations are written for speech. Exact model names and procurement links remain available in the original report: Milesight UC511/UC512, Dragino SE01-LB/LS, Vegetronix VH400, Progrés Agrónic/AgroBee-L, OpenSprinkler, Irrigatia, Tropf-Blumat, PlantCare PlantControl CX, Open_Irr and CatWAN Farmer.

## Downloadable original documents

These are the original research report's document links, offered for addition to the library. They are not newly imported source PDFs. Dates and access limitations reproduce the verified research record from 3 November 2026; no fresh irrigation-source revalidation is claimed for this formatting task.

- [Mejora en la eficiencia del uso de agua y fertilizantes en agricultura — Cajamar Caja Rural, Juan Carlos Gázquez coordinator, March 2018 — direct PDF](https://publicacionescajamar.es/wp-content/uploads/2023/03/mejora-en-la-eficiencia-del-uso-de-agua-2.pdf).
- [Tropf-Blumat user manual — Blumat, undated edition — direct PDF](https://www.blumat.com/storage/app/media/tropf/manual/Tropf-Blumat_user_manual_EN.pdf).
- [Tank Series instructions, batch IRR-5290 — Irrigatia, undated edition — direct PDF](https://www.irrigatia.com/assets/uploads/pdf/TSV2/Tank-Series-Instructions-5290-V2-UK.pdf).
- [Technical Manual LIFE NIEBLAS — LIFE NIEBLAS partners / GESPLAN, legal deposit 2024; website lists Technical Manual 2025 — direct PDF](https://lifenieblas.com/sites/default/files/documentacion/2024/Techcnical%20Manual%20LIFE%20NIEBLAS%20-ENG_0.pdf). Precise publication date unresolved.
- [Assessment of Low-Cost and Higher-End Soil Moisture Sensors across Various Moisture Ranges and Soil Textures — Rajesh Nandi and Dev Shrestha, University of Idaho / Sensors, 11 September 2024 — publisher PDF](https://www.mdpi.com/1424-8220/24/18/5886/pdf?version=1726049298). Previously opened through the research browser; a separate automated download received HTTP 403, so access may be intermittent. [Archive article page](https://pmc.ncbi.nlm.nih.gov/articles/PMC11435841/).
- [PCJ Dripper technical sheet — Netafim, undated edition — direct PDF](https://www.netafim.co.za/globalassets/products/drippers-and-dripperlines/pcj/pcj-dripper-p.pdf).
- [UC51x Series datasheet — Milesight, undated edition — direct PDF](https://resource.milesight.com/milesight/iot/document/uc51x-series-datasheet-en.pdf).
- [Überwachung und automatische Bewässerung von Stadtgrün — PlantCare, undated brochure — direct PDF](https://plant-care.ch/wp-content/uploads/2023/01/PlantCare-Urban-Green.pdf).

The [original register](../SOURCES.md) distinguishes institutional guidance, manufacturer claims, research, proposals, existing library holdings and failed retrievals. Original engineering assumptions remain assumptions in the listening version. The twelve figure PNGs are byte-identical copies of the original package's drawings, embedded inside the EPUB and browser document.

## ElevenReader format evidence

[How to Use Text-to-Speech With EPUB Files — ElevenReader Team, updated 30 October 2026](https://elevenreader.io/blog/epub-text-to-speech) was opened on 3 November 2026. It supports direct EPUB upload, reflowable text and following the text while listening. It does not establish that this particular file's diagrams or highlighting will survive every version of the importer.

[What do I need to look out for in the publishing editor? — ElevenLabs, undated guidance](https://elevenlabs.io/docs/help-center/product/distribution-publishing/elevenreader-publishing/what-do-i-need-to-look-out-for-in-the-publishing-editor) was opened on 3 November 2026. It recommends checking complete chapter transfer, appropriate heading levels and removal of artifacts, and warns that formatting can change. This is publishing-editor guidance, not a guarantee of private-import behaviour.

The indexed file-import help URL redirected to sign-in on a direct open. The accessible ElevenReader article above independently supports the EPUB choice. No assumption is made that the application skips image alt text, special appendices or footnotes. Sources are separate files, rather than content that an importer is expected to hide from narration.

## Production and checks

The EPUB 3 archive contains twelve chapter files, chapter/illustration navigation, compatibility navigation, language metadata, a reflowable stylesheet and twelve PNG resources. Every image is in the reading order at its relevant passage. Text remains text, rather than images of pages. Prose explains diagrams so that the narrative remains understandable without viewing them.

The build checked ZIP integrity, the first uncompressed EPUB mimetype entry, XML parsing, manifest identity and resource presence, chapter order, complete text readback, all twelve image references and alt text, image-byte identity, chapter navigation and figure anchors. These are local package checks, not a claimed EPUBCheck certification.

The self-contained browser document was opened in an isolated headless Chrome profile. All twelve images loaded. Chapter and image counts were checked, and opening and closing the enlarged-image dialog was exercised. Desktop at 1,280 pixels and mobile at 390 pixels had no horizontal document overflow. Screenshots of diagram/prose passages were inspected at both widths. On a phone, dense technical labels require magnification; the browser copy offers an enlarged view.

The final narration has 5,632 words and an estimated listening duration of 35–43 minutes at 130–160 words per minute. Actual duration depends on voice, pauses and speed. No audio was generated. Direct ElevenReader import, playback, image rendering and word highlighting remain untested. The browser read-along is not playback-synchronised.

The source report SHA-256 recorded at production is `270b1b8bbf5ae967e46d3943b27ebec754d90f45512e517802d0b09b389029ac`. Retained machine-readable package and browser results are linked from the package README. Source report and original figure bytes remain unchanged.
